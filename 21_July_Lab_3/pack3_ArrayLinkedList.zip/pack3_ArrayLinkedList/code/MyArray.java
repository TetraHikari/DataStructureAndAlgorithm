package code;

public class MyArray {
    
}
