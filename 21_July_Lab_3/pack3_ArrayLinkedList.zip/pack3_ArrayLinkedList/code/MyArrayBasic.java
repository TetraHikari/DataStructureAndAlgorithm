package code;

public class MyArrayBasic {
    protected int MAX_SIZE = 5;
    protected int data[] = new int[MAX_SIZE];
    protected int size = 0;

    public MyArrayBasic(int ... d){
        for (int i = 0; i < d.length; i++)
            add(d[i]);
    }

    public void add(int d){
        if (size < MAX_SIZE) {
            data[size] = d;
            size++;
        }
    }

    public void insert(int d, int index){
        if (size < MAX_SIZE) {
            for (int i = size; i > index; i--)
                data[i] = data[i-1];
            data[index] = d;
            size++;
        }
    }

    public void find(int d){
        for (int i = 0:)
    }



}
